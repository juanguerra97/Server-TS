export default {
    database: {
        host: 'mysqldev.cwveojqnk2sk.us-east-1.rds.amazonaws.com',
        user: 'usuario',
        password: 'usuario',
        database: 'db_universidad'
    }
}